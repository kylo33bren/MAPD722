import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatefulWidget {
  @override
  _CalculatorAppState createState() => _CalculatorAppState();
}

class _CalculatorAppState extends State<CalculatorApp> {
  String _expression = '';
  String _result = '';


  void _addToExpression(String value) {
    setState(() {
      _expression += value;
    });
  }

  void _clearExpression() {
    setState(() {
      _expression = '';
    });
  }

  void _removeLastCharacter() {
    setState(() {
      _expression = _expression.substring(0, _expression.length - 1);
    });
  }

  void _calculate() {
    Parser p = Parser();
    Expression exp = p.parse(_expression);
    ContextModel cm = ContextModel();
    double eval = exp.evaluate(EvaluationType.REAL, cm);
    setState(() {
      _result = eval.toString();
    });
  }

  void _evaluateExpression() {
    try {
      final expression = Parser().parse(_expression);
      final result = expression.evaluate(EvaluationType.REAL, null);
      setState(() {
        _expression = result.toString();
      });
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Calculator'),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              _expression,
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 16),
            Text(
              _result,
              style: TextStyle(fontSize: 24),
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _addToExpression('1'),
                  child: Text('1'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('2'),
                  child: Text('2'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('3'),
                  child: Text('3'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('+'),
                  child: Text('+'),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _addToExpression('4'),
                  child: Text('4'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('5'),
                  child: Text('5'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('6'),
                  child: Text('6'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('-'),
                  child: Text('-'),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _addToExpression('7'),
                  child: Text('7'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('8'),
                  child: Text('8'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('9'),
                  child: Text('9'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('*'),
                  child: Text('*'),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () => _addToExpression('('),
                  child: Text('('),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('0'),
                  child: Text('0'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression(')'),
                  child: Text(')'),
                ),
                ElevatedButton(
                  onPressed: () => _addToExpression('/'),
                  child: Text('/'),
                ),
              ],
            ),
            SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => _evaluateExpression(),
                  child: Text('='),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}