import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reordering Layout',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Reordering Layout'),
        ),
        body: Stack(
          children: [
            Container(
              color: Colors.blue,
              child: Text('Blue'),
            ),
            Positioned(
              top: 50,
              left: 50,
              child: Container(
                color: Colors.green,
                child: Text('Green'),
              ),
            ),
            Center(
              child: Text(
                'Hello, world!',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
