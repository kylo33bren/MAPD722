import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Resizing Layout',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Resizing Layout'),
        ),
        body: Column(
          children: [
            Expanded(
              child: Container(
                color: Colors.blue,
                child: Center(
                  child: Text('This area will resize dynamically'),
                ),
              ),
            ),
            Container(
              color: Colors.green,
              width: 100,
              child: Center(
                child: Text('This area has a fixed width'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
