import 'package:flutter/material.dart';

void main() => runApp(AboutMeApp());

class AboutMeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'About Me',
      home: Scaffold(
        appBar: AppBar(
          title: Text('About Me'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Brendan Rodrigues',
                style: TextStyle(fontSize: 30),
              ),
              SizedBox(height: 10),
              Text(
                '301119016',
                style: TextStyle(fontSize: 20),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
