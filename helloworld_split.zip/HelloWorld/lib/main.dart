import 'package:flutter/material.dart';
import 'package:split_view/split_view.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Reordering Layout',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Reordering Layout'),
        ),
        body: SplitView(
          view1: Container(
            color: Colors.blue,
            child: Text('First'),
          ),
          view2: Container(
            color: Colors.green,
            child: Text('Second'),
          ),
          viewMode: SplitViewMode.Horizontal,
          gripColor: Colors.transparent,
          gripSize: 10,
          initialWeight: 0.5,
        ),
      ),
    );
  }
}
