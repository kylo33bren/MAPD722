import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quotes App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: QuoteList(),
    );
  }
}

class QuoteList extends StatefulWidget {
  @override
  _QuoteListState createState() => _QuoteListState();
}

class _QuoteListState extends State<QuoteList> {
  List<dynamic> _quotes = [];

  @override
  void initState() {
    super.initState();
    _fetchQuotes();
  }

  Future<void> _fetchQuotes() async {
    final response =
    await http.get(Uri.parse('https://type.fit/api/quotes?limit=10'));

    if (response.statusCode == 200) {
      setState(() {
        _quotes = jsonDecode(response.body);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Quotes App'),
      ),
      body: ListView.builder(
        itemCount: _quotes.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(_quotes[index]['text']),
            subtitle: Text(_quotes[index]['author'] ?? ''),
          );
        },
      ),
    );
  }
}
